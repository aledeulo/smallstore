package com.salesforce.smallstore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmallstoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
